package com.example.haitiembj

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
